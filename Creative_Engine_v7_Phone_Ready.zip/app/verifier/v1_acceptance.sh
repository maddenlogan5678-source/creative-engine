#!/bin/bash
# Acceptance test v1: boot server, hit every endpoint, check all 200/expected codes.
cd "$(dirname "$0")/.."
PORT=8930
python3 -m uvicorn server:app --port $PORT >/dev/null 2>&1 &
SRV=$!
sleep 6
FAIL=0
check() { code=$(curl -s -o /tmp/out.json -w "%{http_code}" "$@"); expected=$1
  # args shift: first arg is expected code
  expected=$1; shift
  code=$(curl -s -o /tmp/out.json -w "%{http_code}" "$@")
  if [ "$code" = "$expected" ]; then echo "PASS $code $*"; else echo "FAIL $code (want $expected) $*"; FAIL=1; fi }
check 200 http://localhost:$PORT/
check 200 http://localhost:$PORT/api/options
check 200 http://localhost:$PORT/api/characters
check 200 http://localhost:$PORT/api/gallery
check 200 -X POST http://localhost:$PORT/api/story -H "Content-Type: application/json" -d '{"topic":"test story","persona":"Mei"}'
check 200 -X POST http://localhost:$PORT/api/rp/send -H "Content-Type: application/json" -d '{"character_id":"mei","message":"hello","tone":5}'
check 422 -X POST http://localhost:$PORT/api/story -H "Content-Type: application/json" -d '{"topic":"porn scene"}'
check 422 -X POST http://localhost:$PORT/api/rp/send -H "Content-Type: application/json" -d '{"character_id":"mei","message":"pissing on you"}'
check 404 http://localhost:$PORT/img/nonexistent.png
check 200 http://localhost:$PORT/api/rp/mei/history
kill $SRV 2>/dev/null
exit $FAIL
