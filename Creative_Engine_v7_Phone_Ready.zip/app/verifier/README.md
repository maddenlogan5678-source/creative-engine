
## v1 — 2026-10-07T14:30:51.537181
Boot uvicorn, check all 10 endpoints (200/422/404). Baseline: covers story, rp, gallery, refs, safety.

## v1 rerun — 2026-10-07T14:42:58.720651
9/9 endpoints after gothic romance + trainer roster additions.
